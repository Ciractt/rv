<?php

include_once OVERWORLD_CORE_SHORTCODES_PATH . '/dropcaps/functions.php';
include_once OVERWORLD_CORE_SHORTCODES_PATH . '/dropcaps/dropcaps.php';