<?php
require_once 'tournament-slider.php';
require_once 'helper-functions.php';