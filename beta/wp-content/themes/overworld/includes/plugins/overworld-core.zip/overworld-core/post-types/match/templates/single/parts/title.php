<div class="edgtf-match-info-item">
	<h2 class="edgtf-match-title"><?php the_title(); ?></h2>
</div>