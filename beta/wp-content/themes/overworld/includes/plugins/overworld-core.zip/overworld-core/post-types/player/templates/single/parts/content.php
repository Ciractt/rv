<div class="edgtf-player-single-content">
	<?php the_content(); ?>
</div>