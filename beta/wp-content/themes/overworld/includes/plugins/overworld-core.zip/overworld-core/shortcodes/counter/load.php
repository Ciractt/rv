<?php

include_once OVERWORLD_CORE_SHORTCODES_PATH . '/counter/functions.php';
include_once OVERWORLD_CORE_SHORTCODES_PATH . '/counter/counter.php';