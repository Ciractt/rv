<?php

include_once OVERWORLD_CORE_CPT_PATH . '/player/player-register.php';
include_once OVERWORLD_CORE_CPT_PATH . '/player/helper-functions.php';