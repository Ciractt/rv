<?php

include_once OVERWORLD_CORE_SHORTCODES_PATH . '/link-list/functions.php';
include_once OVERWORLD_CORE_SHORTCODES_PATH . '/link-list/link-list.php';